import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class WebElement {

	public static void main(String[] args) {
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.google.com/");
		driver.findElement(By.name("q")).sendKeys("Girish sir");
		driver.findElement(By.name("btnK")).click();

	}

}
